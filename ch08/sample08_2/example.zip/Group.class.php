class Group {
    private $conn;
    
    public function __construct($db) {
        $this->conn = $db;
    }

    public function getUsersByGroupId($group_id) {
        $query = "SELECT u.* FROM users u
                  JOIN user_group ug ON u.id = ug.user_id
                  WHERE ug.group_id = :group_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':group_id', $group_id);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function addUserToGroup($user_id, $group_id) {
        $query = "INSERT INTO user_group (user_id, group_id) VALUES (:user_id, :group_id)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':group_id', $group_id);
        $stmt->execute();
    }

    public function removeUserFromGroup($user_id, $group_id) {
        $query = "DELETE FROM user_group WHERE user_id = :user_id AND group_id = :group_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':group_id', $group_id);
        $stmt->execute();
    }

    public function getGroupById($group_id) {
        $query = "SELECT * FROM groups WHERE id = :group_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':group_id', $group_id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}